import { create } from 'zustand';
import { Stock, PortfolioMetrics } from '../types/stock';

interface PortfolioState {
  stocks: Stock[];
  addStock: (stock: Omit<Stock, 'id' | 'currentPrice'>) => void;
  updateStock: (id: string, stock: Partial<Stock>) => void;
  deleteStock: (id: string) => void;
  updateStockPrice: (symbol: string, price: number) => void;
  getMetrics: () => PortfolioMetrics;
}

const mockStocks: Stock[] = [
  { id: '1', symbol: 'AAPL', name: 'Apple Inc.', quantity: 1, buyPrice: 150, currentPrice: 155 },
  { id: '2', symbol: 'GOOGL', name: 'Alphabet Inc.', quantity: 1, buyPrice: 2800, currentPrice: 2850 },
  { id: '3', symbol: 'MSFT', name: 'Microsoft Corporation', quantity: 1, buyPrice: 280, currentPrice: 285 },
  { id: '4', symbol: 'AMZN', name: 'Amazon.com Inc.', quantity: 1, buyPrice: 3200, currentPrice: 3250 },
  { id: '5', symbol: 'TSLA', name: 'Tesla Inc.', quantity: 1, buyPrice: 900, currentPrice: 950 },
];

export const usePortfolioStore = create<PortfolioState>((set, get) => ({
  stocks: mockStocks,
  
  addStock: (stock) => set((state) => ({
    stocks: [...state.stocks, { ...stock, id: Math.random().toString(), currentPrice: stock.buyPrice }]
  })),
  
  updateStock: (id, updatedStock) => set((state) => ({
    stocks: state.stocks.map((stock) => 
      stock.id === id ? { ...stock, ...updatedStock } : stock
    )
  })),
  
  deleteStock: (id) => set((state) => ({
    stocks: state.stocks.filter((stock) => stock.id !== id)
  })),
  
  updateStockPrice: (symbol, price) => set((state) => ({
    stocks: state.stocks.map((stock) =>
      stock.symbol === symbol ? { ...stock, currentPrice: price } : stock
    )
  })),
  
  getMetrics: () => {
    const stocks = get().stocks;
    const totalValue = stocks.reduce((sum, stock) => sum + stock.currentPrice * stock.quantity, 0);
    const totalGainLoss = stocks.reduce((sum, stock) => 
      sum + ((stock.currentPrice - stock.buyPrice) * stock.quantity), 0);
    
    const performers = stocks.map(stock => ({
      ...stock,
      performance: ((stock.currentPrice - stock.buyPrice) / stock.buyPrice) * 100
    }));
    
    const topPerformer = performers.length ? 
      stocks[performers.indexOf(performers.reduce((max, p) => p.performance > max.performance ? p : max))] :
      null;
      
    const worstPerformer = performers.length ?
      stocks[performers.indexOf(performers.reduce((min, p) => p.performance < min.performance ? p : min))] :
      null;
    
    return {
      totalValue,
      totalGainLoss,
      topPerformer,
      worstPerformer
    };
  }
}));