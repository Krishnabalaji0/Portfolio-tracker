import React from 'react';
import { usePortfolioStore } from '../store/usePortfolioStore';
import { TrendingUp, TrendingDown, DollarSign, BarChart } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { getMetrics } = usePortfolioStore();
  const metrics = getMetrics();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Total Portfolio Value</p>
            <p className="text-2xl font-bold">${metrics.totalValue.toFixed(2)}</p>
          </div>
          <DollarSign className="h-8 w-8 text-blue-500" />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Total Gain/Loss</p>
            <p className={`text-2xl font-bold ${metrics.totalGainLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              ${metrics.totalGainLoss.toFixed(2)}
            </p>
          </div>
          <BarChart className="h-8 w-8 text-blue-500" />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Top Performer</p>
            <p className="text-lg font-bold">{metrics.topPerformer?.symbol || 'N/A'}</p>
            {metrics.topPerformer && (
              <p className="text-sm text-green-500">
                ${(metrics.topPerformer.currentPrice - metrics.topPerformer.buyPrice).toFixed(2)}
              </p>
            )}
          </div>
          <TrendingUp className="h-8 w-8 text-green-500" />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Worst Performer</p>
            <p className="text-lg font-bold">{metrics.worstPerformer?.symbol || 'N/A'}</p>
            {metrics.worstPerformer && (
              <p className="text-sm text-red-500">
                ${(metrics.worstPerformer.currentPrice - metrics.worstPerformer.buyPrice).toFixed(2)}
              </p>
            )}
          </div>
          <TrendingDown className="h-8 w-8 text-red-500" />
        </div>
      </div>
    </div>
  );
};