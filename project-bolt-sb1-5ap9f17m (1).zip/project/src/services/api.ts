import axios from 'axios';
import { Stock } from '../types/stock';

const API_URL = 'http://localhost:8080/api';

export const api = {
  getAllStocks: async () => {
    const response = await axios.get(`${API_URL}/stocks`);
    return response.data;
  },

  addStock: async (stock: Omit<Stock, 'id' | 'currentPrice'>) => {
    const response = await axios.post(`${API_URL}/stocks`, stock);
    return response.data;
  },

  updateStock: async (id: string, stock: Partial<Stock>) => {
    const response = await axios.put(`${API_URL}/stocks/${id}`, stock);
    return response.data;
  },

  deleteStock: async (id: string) => {
    await axios.delete(`${API_URL}/stocks/${id}`);
  }
};