package com.example.portfoliotracker.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class StockPriceService {
    @Value("${alphavantage.api.key}")
    private String apiKey;
    
    @Value("${alphavantage.api.url}")
    private String apiUrl;
    
    private final RestTemplate restTemplate;

    public Double getCurrentPrice(String symbol) {
        String url = String.format("%s?function=GLOBAL_QUOTE&symbol=%s&apikey=%s", 
            apiUrl, symbol, apiKey);
            
        Map<String, Object> response = restTemplate.getForObject(url, Map.class);
        Map<String, String> quote = (Map<String, String>) response.get("Global Quote");
        return Double.parseDouble(quote.get("05. price"));
    }
}