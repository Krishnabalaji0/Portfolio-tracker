package com.example.portfoliotracker.service;

import com.example.portfoliotracker.model.Stock;
import com.example.portfoliotracker.repository.StockRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class StockService {
    private final StockRepository stockRepository;
    private final StockPriceService stockPriceService;

    public List<Stock> getAllStocks() {
        return stockRepository.findAll();
    }

    public Stock addStock(Stock stock) {
        // Update current price from Alpha Vantage
        Double currentPrice = stockPriceService.getCurrentPrice(stock.getSymbol());
        stock.setCurrentPrice(currentPrice);
        return stockRepository.save(stock);
    }

    public Stock updateStock(Long id, Stock stock) {
        Stock existingStock = stockRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Stock not found"));
        
        existingStock.setSymbol(stock.getSymbol());
        existingStock.setName(stock.getName());
        existingStock.setQuantity(stock.getQuantity());
        existingStock.setBuyPrice(stock.getBuyPrice());
        existingStock.setCurrentPrice(stockPriceService.getCurrentPrice(stock.getSymbol()));
        
        return stockRepository.save(existingStock);
    }

    public void deleteStock(Long id) {
        stockRepository.deleteById(id);
    }
}